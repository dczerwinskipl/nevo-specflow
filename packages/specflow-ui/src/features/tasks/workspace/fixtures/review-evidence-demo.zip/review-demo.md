# Raport przykładowy

To lokalny materiał demonstracyjny mocka UX, nie dowód odbioru produkcyjnego zadania.

W archiwum znajduje się również przykładowy screenshot interfejsu.
